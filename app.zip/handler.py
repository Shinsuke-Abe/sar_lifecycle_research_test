def hello(event, context):
    return {
        "message": "This function for research repository lifecycle",
        "event": "hello!" 
    }
